## AGPL-3.0 License

Copyright (c) 2020, Aislyn Rose.

Permission to use, copy, modify, and/or distribute this software
under the terms of the GNU General Public License as published by the
<a href="http://fsf.org">Free Software Foundation</a>, either version 3 of the License, or (at your option) 
any later version.

The SoundPy framework  is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or 
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more 
details. 
