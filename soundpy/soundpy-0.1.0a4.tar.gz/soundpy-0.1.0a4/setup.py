# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['soundpy']

package_data = \
{'': ['*']}

install_requires = \
['ipython>=7.27.0,<8.0.0',
 'matplotlib>=3.2.2,<4.0.0',
 'scipy>=1.7.1,<2.0.0',
 'sklearn>=0.0,<0.1']

setup_kwargs = {
    'name': 'soundpy',
    'version': '0.1.0a4',
    'description': 'Audio dataset and feature exploration package for visualization, filtering, and machine learning.',
    'long_description': None,
    'author': 'Aislyn Rose',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<3.10',
}


setup(**setup_kwargs)
