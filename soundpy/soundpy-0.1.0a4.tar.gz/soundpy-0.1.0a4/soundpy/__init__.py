"""
    @author

    _    _     _               ____                
   / \  (_)___| |_   _ _ __   |  _ \ ___  ___  ___ 
  / _ \ | / __| | | | | '_ \  | |_) / _ \/ __|/ _ \
 / ___ \| \__ \ | |_| | | | | |  _ < (_) \__ \  __/
/_/   \_\_|___/_|\__, |_| |_| |_| \_\___/|___/\___|
                 |___/                             

    Email: rose.aislyn.noelle@gmail.com
"""

###############################################################################
from . import utils
from . import feats
from . import files
from . import datasets
from . import filters
from . import dsp
from . import builtin
from . import exceptions as errors
from . import augment
from .utils import check_dir, string2pathlib
from .files import loadsound, savesound
from .feats import plotsound, normalize
from .filters import WienerFilter, BandSubtraction
from .dsp import generate_sound, generate_noise
from .builtin import filtersignal 

__all__=['utils', 'feats', 'filters', 'WienerFilter', 'BandSubtraction', 
         'filtersignal', 'dsp','errors', 'plotsound', 'loadsound', 'savesound',
         'datasets', 'generate_sound', 'playsound',
         'generate_noise', 'builtin', 'augment', 'check_dir', 'string2pathlib',
         'normalize']
